# Treino Básico
- Ponte
- Cem
- Alongamento final