# Treino Idoso
- Mobilidade leve
- Respiração
- Alongamento suave