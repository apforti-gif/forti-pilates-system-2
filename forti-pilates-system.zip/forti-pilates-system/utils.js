function saudacao(nome) {
    return `Olá, ${nome}!`;
}
module.exports = { saudacao };