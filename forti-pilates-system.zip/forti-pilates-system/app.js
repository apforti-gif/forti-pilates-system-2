const alunos = require('./alunos.json');
console.log("Lista de alunos:");
alunos.forEach(a => console.log(a.nome + " - " + a.horario));